const express = require("express");
const path = require("path");
const axios = require("axios"); 
const mongoose = require("mongoose");
const user = require("./models/User");
const bcrypt = require("bcrypt");


app.use(express.urlencoded({extended: true}));
app.use(express.json);

mongoose.connect("mongodb://127.0.0.1:27017/flightDB")
.then(() => {
  console.log("MongoDB Connected");
})
.catch((err) => console.log(err));


const port = 8080;  
const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "ui"));

app.get("/", (req, res) => {
    res.render("index", {
        title: "Home Page"
    });
});


// Flight Route
app.get("/flight", async (req, res) => {

    try {

        const response = await axios.get("https://jsonplaceholder.typicode.com/users");

        // API data 
        const flights = response.data.map(user => ({
            name: user.name,
            from: user.address.city,
            to: user.address.street
        }));

        res.render("flight", {
            title: "Flight Page",
            flights: flights
        });

    } catch (error) {
        console.log(error);
        res.send("Error loading flights");
    }

});


app.get("/product", (req, res)=>{
  res.render("product",{
    title: "Product Page"
  })
});



//login routes
app.get("/login", (req, res)=>{
  res.render("login",{
    title: "Login Page"
  })
});



//register routes
app.get("/register", (req, res)=>{
  try{
    const {name,email,password}=req.body;
    const existUser= await User.findOne({email});
    if(existUser)
    {
      return response.send("User is already register");
    }

    // hash password
    const hashPassword=await bcrypt.hash(password,15);
 } catch(error){

 }
  res.render("register",{
    title: "Register Page"
  })
});




app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
